var gameManager = {

};